**InstaCart** aims to address the inconvenience of online shopping by providing users with a streamlined and user-friendly mobile platform. The app will focus on improving the overall shopping experience, making it more efficient and enjoyable for users.

**Test credentials**

**username**chamalaomprakash2001@gmail.com

**password**Bunty@123

**User Authentication (Activity: LoginActivity)**
Purpose: Allow users to create accounts or log in securely.
Data: Persist user data such as username, password, and personal preferences.

**Product Browsing (Activity: ProductListActivity)**
Purpose: Display a list of products with filtering and sorting options.
Data: Retrieve and display product information, including images, prices, and descriptions.

**Shopping Cart (Activity: ShoppingCartActivity)**
Purpose: Allow users to add/remove items from their shopping cart.
Data: Persist the user's shopping cart, including product details and quantities.

**Checkout (Activity: CheckoutActivity)**
Purpose: Enable users to review their order, enter shipping details, and complete the purchase.
Data: Process transaction details, including billing and shipping information.

**User Profile (Activity: UserProfileActivity)**
Purpose: Allow users to view and update their profile information.
Data: Store and retrieve user profile data.

**Create Account (Activity: CreateAccountActivity)**
Purpose: Allow new users to register by providing necessary information.
Data: Collect user details such as username, password, email, and other information for account creation.
